#simple exercise of asignments of numbers, doubling the number, changing values, print them

number = 15
print(number)
number = 2 * 15
print(number)

my_string = "apples"
print(number, my_string)
# print(my_string)

numberSquared = number ** 2
my_string = "pears"
print(numberSquared, my_string)
# print(my_string)
